// ReportDemo.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "ReportDemo.h"

#include "MainFrm.h"
#include "ReportDemoDoc.h"
#include "ReportDemoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CReportDemoApp

BEGIN_MESSAGE_MAP(CReportDemoApp, CWinApp)
	//{{AFX_MSG_MAP(CReportDemoApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CReportDemoApp construction

CReportDemoApp::CReportDemoApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CReportDemoApp object

CReportDemoApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CReportDemoApp initialization

BOOL CReportDemoApp::InitInstance()
{
	// Standard initialization

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	// Change the registry key under which our settings are stored.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	// Register document templates

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CReportDemoDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CReportDemoView));
	AddDocTemplate(pDocTemplate);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

#include "ReportCtrl.h"

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CReportCtrl	m_rcAbout;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnRvnItemDrawPreview(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Control(pDX, IDC_REPORT, m_rcAbout);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	ON_NOTIFY(RVN_ITEMDRAWPREVIEW, IDC_REPORT, OnRvnItemDrawPreview)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CReportDemoApp message handlers

// App command to run the dialog
void CReportDemoApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg message handlers


BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	RVCOLUMN rvc;
	rvc.lpszText = "Field";
	rvc.iWidth = 100;
	m_rcAbout.DefineColumn(0, &rvc);

	rvc.lpszText = "Data";
	rvc.iWidth = 350;
	m_rcAbout.DefineColumn(1, &rvc);

	m_rcAbout.ActivateColumn(0, 0);
	m_rcAbout.ActivateColumn(1, 1);

	m_rcAbout.InsertItem(0, _T("Title")); m_rcAbout.SetItemText(0, 1, _T("Report Control"));
	m_rcAbout.InsertItem(1, _T("Copyright")); m_rcAbout.SetItemText(1, 1, _T("Copyright (C) 1999 by Maarten Hoeben"));
	m_rcAbout.InsertItem(2, _T("Contact")); m_rcAbout.SetItemText(2, 1, _T("maarten.hoeben@nwn.com"));

	RVITEM rvi;
	rvi.iItem = 0;
	rvi.nMask = RVIM_PREVIEW;
	rvi.nPreview = 32;
	m_rcAbout.SetItem(&rvi);

	rvi.iItem = 1;
	m_rcAbout.SetItem(&rvi);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CAboutDlg::OnRvnItemDrawPreview(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMRVDRAWPREVIEW lpnmrvdp = (LPNMRVDRAWPREVIEW)pNMHDR;

	CDC dc;
	dc.Attach(lpnmrvdp->hDC);
	if(lpnmrvdp->nState&RVIS_SELECTED)
		dc.SetTextColor(::GetFocus()==m_rcAbout.m_hWnd ? GetSysColor(COLOR_HIGHLIGHTTEXT):GetSysColor(COLOR_HIGHLIGHT));
	else
		dc.SetTextColor(GetSysColor(COLOR_HIGHLIGHT));

	lpnmrvdp->rect.left += 40;
	lpnmrvdp->rect.top += 2;
	lpnmrvdp->rect.bottom -= 2;

	CString str;

	switch(lpnmrvdp->iItem)
	{
	case 0: str = _T("An Outlook 98 SUPERGRID Control"); break;
	case 1: str = _T("You are free to use, distribute or modify the code as long as the copyright information is not removed or modified."); break;
	}

	dc.DrawText(str, &lpnmrvdp->rect, DT_LEFT|DT_END_ELLIPSIS|DT_WORDBREAK);

	dc.Detach();
	*pResult = FALSE;
}
