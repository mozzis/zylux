//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ReportDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDC_NODROP                      106
#define IDR_MAINFRAME                   128
#define IDR_REPORTTYPE                  129
#define IDB_DEMO                        131
#define IDB_REPORT                      131
#define IDD_FIELDCHOOSER                132
#define IDC_REPORT                      1001
#define IDC_COLUMNLIST                  1002
#define ID_VIEW_FIELDCHOOSER            32771
#define ID_VIEW_TEST                    32773
#define ID_VIEW_ALTERNATECOLORS         32774
#define ID_VIEW_SHOWSELECTIONALWAYS     32775
#define ID_VIEW_SHOWCOLORALWAYS         32776
#define ID_VIEW_NOHEADER                32777
#define ID_VIEW_SHOWHGRID               32778
#define ID_VIEW_SHOWVGRID               32779

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
