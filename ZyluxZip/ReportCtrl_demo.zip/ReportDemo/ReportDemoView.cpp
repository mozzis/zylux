// ReportDemoView.cpp : implementation of the CReportDemoView class
//

#include "stdafx.h"
#include "ReportDemo.h"
#include "ReportDemoDoc.h"
#include "ReportDemoView.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CReportDemoView

IMPLEMENT_DYNCREATE(CReportDemoView, CReportView)

BEGIN_MESSAGE_MAP(CReportDemoView, CReportView)
	//{{AFX_MSG_MAP(CReportDemoView)
	ON_WM_TIMER()
	ON_NOTIFY(RVN_ITEMDRAWPREVIEW, IDC_REPORTCTRL, OnRvnItemDrawPreview)
	ON_NOTIFY(RVN_ITEMCLICK, IDC_REPORTCTRL, OnRvnItemClick)
	ON_NOTIFY(RVN_ITEMDBCLICK, IDC_REPORTCTRL, OnRvnItemDbClick)
	ON_COMMAND(ID_VIEW_ALTERNATECOLORS, OnViewAlternatecolors)
	ON_UPDATE_COMMAND_UI(ID_VIEW_ALTERNATECOLORS, OnUpdateViewAlternatecolors)
	ON_COMMAND(ID_VIEW_SHOWCOLORALWAYS, OnViewShowcoloralways)
	ON_UPDATE_COMMAND_UI(ID_VIEW_SHOWCOLORALWAYS, OnUpdateViewShowcoloralways)
	ON_COMMAND(ID_VIEW_SHOWSELECTIONALWAYS, OnViewShowselectionalways)
	ON_UPDATE_COMMAND_UI(ID_VIEW_SHOWSELECTIONALWAYS, OnUpdateViewShowselectionalways)
	ON_COMMAND(ID_VIEW_NOHEADER, OnViewNoheader)
	ON_UPDATE_COMMAND_UI(ID_VIEW_NOHEADER, OnUpdateViewNoheader)
	ON_WM_DESTROY()
	ON_COMMAND(ID_VIEW_SHOWHGRID, OnViewShowhgrid)
	ON_UPDATE_COMMAND_UI(ID_VIEW_SHOWHGRID, OnUpdateViewShowhgrid)
	ON_COMMAND(ID_VIEW_SHOWVGRID, OnViewShowvgrid)
	ON_UPDATE_COMMAND_UI(ID_VIEW_SHOWVGRID, OnUpdateViewShowvgrid)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CReportView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CReportView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CReportView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CReportDemoView construction/destruction

CReportDemoView::CReportDemoView()
{
}

CReportDemoView::~CReportDemoView()
{
}

BOOL CReportDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CReportView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CReportDemoView drawing

void CReportDemoView::OnDraw(CDC* pDC)
{
	CReportDemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
}

/////////////////////////////////////////////////////////////////////////////
// CReportDemoView printing

BOOL CReportDemoView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CReportDemoView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

void CReportDemoView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

/////////////////////////////////////////////////////////////////////////////
// CReportDemoView diagnostics

#ifdef _DEBUG
void CReportDemoView::AssertValid() const
{
	CReportView::AssertValid();
}

void CReportDemoView::Dump(CDumpContext& dc) const
{
	CReportView::Dump(dc);
}

CReportDemoDoc* CReportDemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CReportDemoDoc)));
	return (CReportDemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CReportDemoView message handlers

struct structDemoInfo
{
	INT iIcon;
	INT iImportance;
	LPCTSTR lpszReceived;
	LPCTSTR lpszFrom;
	LPCTSTR lpszSubject;

	UINT nPreview;
	LPCTSTR lpszPreview;
} g_sdiInfo[] =
{
	3, 6, _T("Mon 7/12/99 5:49 PM"), _T("Maarten Hoeben"), _T("Report Control - An Outlook 98 SUPERGRID Control"),
	56, _T("\tA great new control with many features that mimic the features and look and feel of the Outlook 98 SUPERGRID control.")
		_T("The control consists of 2 (sub)controls, the ReportCtrl itself and a new version of the previously released FlatHeaderCtrl. "),


	3, 6, _T("Mon 7/12/99 6:50 PM"), _T("Maarten Hoeben"), _T("Report Control - Sorry..."),
	56, _T("\tI did not include documentation, because I don't have time to write any documentation. ")
		_T("However, the included demo is a great help in understanding how to use the features of the control and ")
		_T("many features are demonstrated in a practical manner. The interfaces of the controls highly resemble ")
		_T("the interfaces of similiar MFC controls, like the list control and header control. So, for the more ")
		_T("experienced MFC coder, it should not be a big problem to understand how to use the control in their own ")
		_T("projects..."),

	3, -1, _T("Tue 7/13/99 7:47 PM"), _T("Maarten Hoeben"), _T("License"),
	30, _T("You are free to use, distribute or modify the code as long as the copyright information in the source is not removed or modified. ")
		_T("However, it would be nice to drop me a line if you use it in a serious project. "),

	3, -1, _T("Tue 7/13/99 7:48 PM"), _T("Maarten Hoeben"), _T("Contact info"),
	17, _T("maarten.hoeben@nwn.com"),

	3, -1, _T("Tue 7/13/99 11:00 AM"), _T("Maarten Hoeben"), _T("Bug Fixes"),
	17, _T("Bug reports and fixes should be reported through CodeGuru. Thanks..."),

	3, -1, _T("Tue 7/13/99 11:01 AM"), _T("Maarten Hoeben"), _T("Features..."),
	17, _T("Try rearranging columns through drag and drop."),

	3, -1, _T("Tue 7/13/99 11:02 AM"), _T("Maarten Hoeben"), _T("Features..."),
	30, _T("Select the field chooser (View->Field Chooser) and try adding and removing columns from the report.")
		_T("Note that a specialized ListBox class is provided to facilitate easy implementation of custom ")
		_T("Field Choosers"),

	3, -1, _T("Tue 7/13/99 11:03 AM"), _T("Maarten Hoeben"), _T("Features..."),
	30, _T("Select the alternate background color style (View->Styles->Alternate colors)..."),

	3, -1, _T("Tue 7/13/99 11:04 AM"), _T("Maarten Hoeben"), _T("Features..."),
	30, _T("Select the Check column from the Field Chooser and try checking and unchecking... ")
		_T("The demo code shows you how to handle the notifications sent by the control to ")
		_T("implement more complex operations."),

	3, -1, _T("Tue 7/13/99 11:05 AM"), _T("Maarten Hoeben"), _T("Features..."),
	30, _T("Try sorting columns by clicking on the header. The control sorts on text content ")
		_T("by default. For more complex sorting, the control also supports callback."),

	3, -1, _T("Tue 7/13/99 11:06 AM"), _T("Maarten Hoeben"), _T("Features..."),
	17, _T("Double click on the items to read your email..."),

	3, -1, _T("Fri 7/16/99 3:00 PM"), _T("Maarten Hoeben"), _T("Features..."),
	56, _T("Support for colored text and backgrounds is also included. The control allows you ")
		_T("to define a set of colors. The colors can be assigned to text or background by using ")
		_T("the index of a color in the table. The control will handle palette creation in order ")
		_T("to display the colors as accurate as possible. The Show color always style instructs ")
		_T("the control not to change the text color upon selection (try View->Styles->Show color always)."),

	3, -1, _T("Fri 7/16/99 3:00 PM"), _T("Maarten Hoeben"), _T("Features..."),
	17, _T("You can also hide the header control, whatever you may want to do that for...")
};
INT g_iInfo = 13;

void CReportDemoView::OnInitialUpdate() 
{
	CReportView::OnInitialUpdate();

	static bInit = TRUE;
	if(!bInit)
		return;

	CReportCtrl& rc = GetReportCtrl();

	CMainFrame* pWnd = (CMainFrame*)AfxGetMainWnd();
	m_wndColumnList.SubclassDlgItem(IDC_COLUMNLIST, &pWnd->m_wndFieldChooser);
	rc.SetReportColumnListCtrl(&m_wndColumnList);

	m_ilReport.Create(IDB_REPORT, 16, 1, RGB(255,0,255));
	rc.SetImageList(&m_ilReport);

	rc.InsertColor(0, 0x00C0D8C0);
	rc.InsertColor(1, 0x00D0C0C0);
	rc.InsertColor(2, 0x00804000);

	RVCOLUMN rvc;

	rvc.nFormat = RVCF_IMAGE|RVCF_EX_AUTOWIDTH|RVCF_EX_FIXEDWIDTH|RVCF_SUBITEM_IMAGE;
	rvc.iImage = 0;
	rvc.lpszText = _T("Icon");
	rc.DefineColumn(0, &rvc);

	rvc.nFormat = RVCF_IMAGE|RVCF_EX_AUTOWIDTH|RVCF_EX_FIXEDWIDTH|RVCF_SUBITEM_IMAGE;
	rvc.iImage = 1;
	rvc.lpszText = _T("Importance");
	rc.DefineColumn(1, &rvc);

	rvc.nFormat = RVCF_TEXT;
	rvc.lpszText = _T("Received");
	rc.DefineColumn(2, &rvc);

	rvc.nFormat = RVCF_TEXT;
	rvc.lpszText = _T("From");
	rc.DefineColumn(3, &rvc);

	rvc.nFormat = RVCF_TEXT;
	rvc.lpszText = _T("Subject");
	rc.DefineColumn(4, &rvc);

	rvc.nFormat = RVCF_IMAGE|RVCF_EX_AUTOWIDTH|RVCF_EX_FIXEDWIDTH;
	rvc.iImage = 2;
	rvc.lpszText = _T("Check");
	rc.DefineColumn(5, &rvc);

	if(!rc.GetProfile(_T("Settings"), _T("ReportCtrl")))
	{
		rc.ActivateColumn(0, 0);
		rc.ActivateColumn(1, 1);
		rc.ActivateColumn(2, 2);
		rc.ActivateColumn(3, 3);
		rc.ActivateColumn(4, 4);
	}

	rc.GetHeaderCtrl()->ModifyProperty(FH_PROPERTY_DONTDROPCURSOR, IDC_NODROP);
	rc.ModifyStyle(0, RVS_ALLOWCOLUMNREMOVAL|RVS_SINGLESELECT);

	SetTimer(1, 2000, NULL);
}

void CReportDemoView::OnDestroy() 
{
	CReportCtrl& rc = GetReportCtrl();
	rc.WriteProfile(_T("Settings"), _T("ReportCtrl"));

	CReportView::OnDestroy();	
}

void CReportDemoView::OnTimer(UINT nIDEvent) 
{
	static INT iIndex = 0;

	if(nIDEvent == 1)
	{
		CReportCtrl& rc = GetReportCtrl();

		RVITEM rvi;
		rvi.iItem = iIndex;
		rvi.iSubItem = 0;
		rvi.nMask = RVIM_IMAGE|RVIM_PREVIEW|RVIM_STATE|RVIM_LPARAM;
		rvi.iImage = g_sdiInfo[iIndex].iIcon;
		rvi.nPreview = g_sdiInfo[iIndex].nPreview;
		rvi.nState = RVIS_BOLD;
		rvi.lParam = iIndex;

		if(iIndex == 11)
		{
			rvi.nMask |= RVIM_BKCOLOR;
			rvi.iBkColor = 1;
		}
		
		rc.InsertItem(&rvi);

		rvi.iSubItem = 1;
		rvi.iImage = g_sdiInfo[iIndex].iImportance;
		rc.SetItem(&rvi);

		rvi.iSubItem = 2;
		rvi.nMask = RVIM_TEXT;
		rvi.lpszText = (LPTSTR)g_sdiInfo[iIndex].lpszReceived;
		if(iIndex == 11)
		{
			rvi.nMask |= RVIM_TEXTCOLOR;
			rvi.iTextColor = 2;
		}
		rc.SetItem(&rvi);

		rvi.iSubItem = 3;
		rvi.lpszText = (LPTSTR)g_sdiInfo[iIndex].lpszFrom;
		rc.SetItem(&rvi);

		rvi.iSubItem = 4;
		rvi.lpszText = (LPTSTR)g_sdiInfo[iIndex].lpszSubject;
		rc.SetItem(&rvi);

		rvi.iSubItem = 5;
		rvi.nMask = RVIM_CHECK;
		rvi.iCheck = rand()&1;
		rc.SetItem(&rvi);

		iIndex++;

		if(iIndex < g_iInfo)
			SetTimer(1, 500+(rand()%1000), NULL);
		else
			KillTimer(1);
	}

	CReportView::OnTimer(nIDEvent);
}

void CReportDemoView::OnRvnItemDrawPreview(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMRVDRAWPREVIEW lpnmrvdp = (LPNMRVDRAWPREVIEW)pNMHDR;

	CReportCtrl& rc = GetReportCtrl();

	CDC dc;
	dc.Attach(lpnmrvdp->hDC);
	if(lpnmrvdp->nState&RVIS_SELECTED)
		dc.SetTextColor(::GetFocus()==rc.m_hWnd ? GetSysColor(COLOR_HIGHLIGHTTEXT):GetSysColor(COLOR_HIGHLIGHT));
	else
		dc.SetTextColor(GetSysColor(COLOR_HIGHLIGHT));

	lpnmrvdp->rect.left += 40;
	lpnmrvdp->rect.top += 2;
	lpnmrvdp->rect.bottom -= 2;
	dc.DrawText(g_sdiInfo[lpnmrvdp->iItem].lpszPreview, &lpnmrvdp->rect, DT_LEFT|DT_END_ELLIPSIS|DT_WORDBREAK|DT_NOPREFIX|DT_EXPANDTABS);

	dc.Detach();
	*pResult = FALSE;
}

void CReportDemoView::OnRvnItemClick(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMREPORTVIEW lpnmrv = (LPNMREPORTVIEW)pNMHDR;

	CReportCtrl& rc = GetReportCtrl();

	if(lpnmrv->iItem>=0 && lpnmrv->iSubItem>=0)
	{
		RVITEM rvi;
		rvi.iItem = lpnmrv->iItem;
		rvi.iSubItem = lpnmrv->iSubItem;
		rc.GetItem(&rvi);

		if(rvi.nMask&RVIM_CHECK && lpnmrv->nFlags&RVHT_ONITEMCHECK)
			rvi.iCheck = rvi.iCheck ? 0:1;

		rc.SetItem(&rvi);
	}

	*pResult = FALSE;
}

void CReportDemoView::OnRvnItemDbClick(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMREPORTVIEW lpnmrv = (LPNMREPORTVIEW)pNMHDR;

	CReportCtrl& rc = GetReportCtrl();

	if(lpnmrv->iItem >= 0)
	{
		CString str;
		str.Format(_T("From:\t%s\nSubject:\t%s\n\n%s"),
			rc.GetItemText(lpnmrv->iItem, 3),
			rc.GetItemText(lpnmrv->iItem, 4),
			g_sdiInfo[lpnmrv->iItem].lpszPreview);

		if(MessageBox(str, _T("Message"), MB_ICONINFORMATION|MB_OKCANCEL) == IDOK)
		{
			RVITEM rvi;
			rvi.iItem = lpnmrv->iItem;
			rvi.iSubItem = 0;
			rvi.nMask = RVIM_IMAGE|RVIM_PREVIEW|RVIM_STATE;
			rvi.iImage = 4;
			rvi.nPreview = 0;
			rvi.nState = 0;
			rc.SetItem(&rvi);
		}
	}

	*pResult = FALSE;
}

void CReportDemoView::OnViewAlternatecolors() 
{
	CReportCtrl& rc = GetReportCtrl();
	if(rc.GetStyle()&RVS_SHOWCOLORALTERNATE)
		rc.ModifyStyle(RVS_SHOWCOLORALTERNATE, 0);
	else
		rc.ModifyStyle(0, RVS_SHOWCOLORALTERNATE);
}

void CReportDemoView::OnUpdateViewAlternatecolors(CCmdUI* pCmdUI) 
{
	CReportCtrl& rc = GetReportCtrl();
	pCmdUI->SetCheck(rc.GetStyle()&RVS_SHOWCOLORALTERNATE);
}


void CReportDemoView::OnViewShowcoloralways() 
{
	CReportCtrl& rc = GetReportCtrl();
	if(rc.GetStyle()&RVS_SHOWCOLORALWAYS)
		rc.ModifyStyle(RVS_SHOWCOLORALWAYS, 0);
	else
		rc.ModifyStyle(0, RVS_SHOWCOLORALWAYS);
}

void CReportDemoView::OnUpdateViewShowcoloralways(CCmdUI* pCmdUI) 
{
	CReportCtrl& rc = GetReportCtrl();
	pCmdUI->SetCheck(rc.GetStyle()&RVS_SHOWCOLORALWAYS);
}

void CReportDemoView::OnViewShowselectionalways() 
{
	CReportCtrl& rc = GetReportCtrl();
	if(rc.GetStyle()&RVS_SHOWSELALWAYS)
		rc.ModifyStyle(RVS_SHOWSELALWAYS, 0);
	else
		rc.ModifyStyle(0, RVS_SHOWSELALWAYS);	
}

void CReportDemoView::OnUpdateViewShowselectionalways(CCmdUI* pCmdUI) 
{
	CReportCtrl& rc = GetReportCtrl();
	pCmdUI->SetCheck(rc.GetStyle()&RVS_SHOWSELALWAYS);
}

void CReportDemoView::OnViewNoheader() 
{
	CReportCtrl& rc = GetReportCtrl();
	if(rc.GetStyle()&RVS_NOHEADER)
		rc.ModifyStyle(RVS_NOHEADER, 0);
	else
		rc.ModifyStyle(0, RVS_NOHEADER);	
}

void CReportDemoView::OnUpdateViewNoheader(CCmdUI* pCmdUI) 
{
	CReportCtrl& rc = GetReportCtrl();
	pCmdUI->SetCheck(rc.GetStyle()&RVS_NOHEADER);
}

void CReportDemoView::OnViewShowhgrid() 
{
	CReportCtrl& rc = GetReportCtrl();
	if(rc.GetStyle()&RVS_SHOWHGRID)
		rc.ModifyStyle(RVS_SHOWHGRID, 0);
	else
		rc.ModifyStyle(0, RVS_SHOWHGRID);	
}

void CReportDemoView::OnUpdateViewShowhgrid(CCmdUI* pCmdUI) 
{
	CReportCtrl& rc = GetReportCtrl();
	pCmdUI->SetCheck(rc.GetStyle()&RVS_SHOWHGRID);
}

void CReportDemoView::OnViewShowvgrid() 
{
	CReportCtrl& rc = GetReportCtrl();
	if(rc.GetStyle()&RVS_SHOWVGRID)
		rc.ModifyStyle(RVS_SHOWVGRID, 0);
	else
		rc.ModifyStyle(0, RVS_SHOWVGRID);	
}

void CReportDemoView::OnUpdateViewShowvgrid(CCmdUI* pCmdUI) 
{
	CReportCtrl& rc = GetReportCtrl();
	pCmdUI->SetCheck(rc.GetStyle()&RVS_SHOWVGRID);
}
