// ReportDemoDoc.cpp : implementation of the CReportDemoDoc class
//

#include "stdafx.h"
#include "ReportDemo.h"

#include "ReportDemoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CReportDemoDoc

IMPLEMENT_DYNCREATE(CReportDemoDoc, CDocument)

BEGIN_MESSAGE_MAP(CReportDemoDoc, CDocument)
	//{{AFX_MSG_MAP(CReportDemoDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CReportDemoDoc construction/destruction

CReportDemoDoc::CReportDemoDoc()
{
}

CReportDemoDoc::~CReportDemoDoc()
{
}

BOOL CReportDemoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CReportDemoDoc serialization

void CReportDemoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
	}
	else
	{
	}
}

/////////////////////////////////////////////////////////////////////////////
// CReportDemoDoc diagnostics

#ifdef _DEBUG
void CReportDemoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CReportDemoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CReportDemoDoc commands
