// ReportDemo.h : main header file for the REPORTDEMO application
//

#if !defined(AFX_REPORTDEMO_H__7DE0DC3E_0CA2_11D3_88D7_E9BA6537BD7C__INCLUDED_)
#define AFX_REPORTDEMO_H__7DE0DC3E_0CA2_11D3_88D7_E9BA6537BD7C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CReportDemoApp:
// See ReportDemo.cpp for the implementation of this class
//

class CReportDemoApp : public CWinApp
{
public:
	CReportDemoApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CReportDemoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CReportDemoApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REPORTDEMO_H__7DE0DC3E_0CA2_11D3_88D7_E9BA6537BD7C__INCLUDED_)
