// ReportDemoView.h : interface of the CReportDemoView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_REPORTDEMOVIEW_H__7DE0DC46_0CA2_11D3_88D7_E9BA6537BD7C__INCLUDED_)
#define AFX_REPORTDEMOVIEW_H__7DE0DC46_0CA2_11D3_88D7_E9BA6537BD7C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ReportCtrl.h"

class CReportDemoView : public CReportView
{
protected: // create from serialization only
	CReportDemoView();
	DECLARE_DYNCREATE(CReportDemoView)

// Attributes
public:
	CReportDemoDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CReportDemoView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CReportDemoView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	CReportColumnListCtrl m_wndColumnList;
	CImageList m_ilReport;

// Generated message map functions
protected:
	//{{AFX_MSG(CReportDemoView)
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnRvnItemDrawPreview(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnRvnItemClick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnRvnItemDbClick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnViewAlternatecolors();
	afx_msg void OnUpdateViewAlternatecolors(CCmdUI* pCmdUI);
	afx_msg void OnViewShowcoloralways();
	afx_msg void OnUpdateViewShowcoloralways(CCmdUI* pCmdUI);
	afx_msg void OnViewShowselectionalways();
	afx_msg void OnUpdateViewShowselectionalways(CCmdUI* pCmdUI);
	afx_msg void OnViewNoheader();
	afx_msg void OnUpdateViewNoheader(CCmdUI* pCmdUI);
	afx_msg void OnDestroy();
	afx_msg void OnViewShowhgrid();
	afx_msg void OnUpdateViewShowhgrid(CCmdUI* pCmdUI);
	afx_msg void OnViewShowvgrid();
	afx_msg void OnUpdateViewShowvgrid(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ReportDemoView.cpp
inline CReportDemoDoc* CReportDemoView::GetDocument()
   { return (CReportDemoDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REPORTDEMOVIEW_H__7DE0DC46_0CA2_11D3_88D7_E9BA6537BD7C__INCLUDED_)
