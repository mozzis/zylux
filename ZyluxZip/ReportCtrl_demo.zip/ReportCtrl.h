////////////////////////////////////////////////////////////////////////////
//	File:		CReportCtrl.h
//	Version:	1.0.1.0
//
//	Author:		Maarten Hoeben
//	E-mail:		hoeben@nwn.com
//
//	Specification of the CReportCtrl and associated classes.
//
//	You are free to use, distribute or modify this code
//	as long as the header is not removed or modified.
//
////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_REPORTCTRL_H__279B1CA0_D7F2_11D2_88D7_ABB23645F26D__INCLUDED_)
#define AFX_REPORTCTRL_H__279B1CA0_D7F2_11D2_88D7_ABB23645F26D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ReportCtrl.h : header file
//

#include "MemDC.h"
#include "FlatHeaderCtrl.h"

// Use this as the classname when inserting this control as a custom control
// in the MSVC++ dialog editor
#define REPORTCTRL_CLASSNAME	_T("MFCReportCtrl")
#define REPORTCTRL_MAX_TEXT		256
#define REPORTCTRL_MAX_COLORS	32

#define IDC_HEADERCTRL	0
#define IDC_REPORTCTRL	0

// Properties
#define RVP_SPACING			1
#define RVP_CHECK			2
#define RVP_NOITEMTEXT		3
#define RVP_GRIDSTYLE		4

#define RVP_GRIDSTYLE_DOT			0
#define RVP_GRIDSTYLE_DASH			1
#define RVP_GRIDSTYLE_SOLID			2

// Styles
#define RVS_SINGLESELECT		0x0001
#define RVS_SHOWSELALWAYS		0x0002
#define RVS_SHOWCOLORALWAYS		0x0004
#define RVS_SHOWCOLORALTERNATE	0x0008
#define RVS_SHOWHGRID			0x0010
#define RVS_SHOWVGRID			0x0020
#define RVS_NOHEADER			0x0040
#define RVS_NOSORT				0x0080
#define RVS_ALLOWCOLUMNREMOVAL	0x0100

// Column Format
#define RVCF_LEFT			HDF_LEFT
#define RVCF_RIGHT			HDF_RIGHT
#define RVCF_CENTER			HDF_CENTER
#define RVCF_TEXT			HDF_STRING
#define RVCF_IMAGE			HDF_IMAGE

#define	RVCF_JUSTIFYMASK	HDF_JUSTIFYMASK
#define RVCF_MASK			0x0000ffff

#define RVCF_EX_AUTOWIDTH	(HDF_EX_AUTOWIDTH<<16)
#define RVCF_EX_INCLUDESORT	(HDF_EX_INCLUDESORT<<16)
#define RVCF_EX_FIXEDWIDTH	(HDF_EX_FIXEDWIDTH<<16)
#define RVCF_EX_MASK		0x00ff0000

#define RVCF_SUBITEM_IMAGE	0x01000000
#define RVCF_SUBITEM_CHECK	0x02000000
#define RVCF_SUBITEM_MASK	0xff000000

typedef struct _RVCOLUMN
{
    UINT	nFormat;
    INT		iWidth;
	INT		iMinWidth;
	INT		iMaxWidth;
    INT		iImage;

    LPTSTR	lpszText;

	_RVCOLUMN() : nFormat(RVCF_LEFT|RVCF_TEXT), iWidth(-1), iMinWidth(0), iMaxWidth(-1), iImage(0), lpszText(NULL) {};

} RVCOLUMN, FAR* LPRVCOLUMN;

// Item Masks
#define RVIM_TEXT			0x0001
#define RVIM_TEXTCOLOR		0x0002
#define RVIM_IMAGE			0x0004
#define RVIM_CHECK			0x0008
#define RVIM_BKCOLOR		0x0010
#define RVIM_PREVIEW		0x0020
#define RVIM_STATE			0x0040
#define RVIM_LPARAM			0x0080

// Item State
#define RVIS_FOCUSED		0x0001
#define RVIS_SELECTED		0x0002
#define RVIS_BOLD			0x0004

typedef struct _RVITEM
{
	UINT		nMask;
	INT			iItem;
	INT			iSubItem;

	LPTSTR		lpszText;
	INT			iTextMax;
	INT			iTextColor;

	INT			iImage;
	INT			iCheck;

	INT			iBkColor;
	UINT		nPreview;
	UINT		nState;

	LPARAM		lParam;

	_RVITEM() : nMask(0), iItem(-1), iSubItem(-1), lpszText(NULL), iTextMax(0), iTextColor(-1), iImage(-1), iCheck(-1), iBkColor(-1), nPreview(0), nState(0), lParam(0) {};

} RVITEM, FAR* LPRVITEM;

// Hit Test
#define RVHT_NOWHERE			0x0001
#define RVHT_ONITEMIMAGE		0x0002
#define RVHT_ONITEMCHECK		0x0004
#define RVHT_ONITEMTEXT			0x0008
#define RVHT_ONITEMPREVIEW		0x0010
#define RVHT_ONITEM				(RVHT_ONITEMIMAGE|RVHT_ONITEMCHECK|RVHT_ONITEMTEXT|RVHT_ONITEMPREVIEW)

#define RVHT_ABOVE				0x0100
#define RVHT_BELOW				0x0200
#define RVHT_TORIGHT			0x0400
#define RVHT_TOLEFT				0x0800

typedef struct _RVHITTESTINFO
{
	POINT	point;
	UINT	nFlags;
	INT		iItem;
	INT		iSubItem;

} RVHITTESTINFO, FAR* LPRVHITTESTINFO;

// Notifications
#define RVN_ITEMDRAWPREVIEW		(0U-2048U)
#define RVN_ITEMCLICK			(0U-2049U)
#define RVN_ITEMDBCLICK			(0U-2050U)
#define RVN_SELECTIONCHANGING	(0U-2051U)
#define RVN_SELECTIONCHANGED	(0U-2052U)
#define RVN_COLUMNCLICK			(0U-2053U)

typedef struct _NMRVDRAWPREVIEW
{
    NMHDR	hdr;

    INT		iItem;
	UINT	nState;
	HDC		hDC;
	RECT	rect;
    LPARAM	lParam;

} NMRVDRAWPREVIEW, FAR* LPNMRVDRAWPREVIEW;

typedef struct _NMREPORTVIEW
{
    NMHDR	hdr;
	UINT	nKeys;

    POINT	point;
	UINT	nFlags;
    INT		iItem;
    INT		iSubItem;
    LPARAM	lParam;

} NMREPORTVIEW, FAR* LPNMREPORTVIEW;

typedef INT (CALLBACK* LPFNRVCOMPARE)(INT iColumn, INT iItem1, INT iItem2);

class CReportData : public CString
{
public:
	CReportData();
	~CReportData();

	BOOL New(INT iSubItems);

	BOOL GetSubItem(INT iSubItem, LPINT lpiImage, LPINT lpiCheck, LPINT lpiColor, LPTSTR lpszText, INT iTextMax);
	BOOL SetSubItem(INT iSubItem, INT iImage, INT iCheck, INT iColor, LPCTSTR lpszText);

	BOOL InsertSubItem(INT iSubItem, INT iImage, INT iCheck, INT iColor, LPCTSTR lpszText);
	BOOL DeleteSubItem(INT iSubItem);
};

class CReportColumnListCtrl;

/////////////////////////////////////////////////////////////////////////////
// CReportCtrl window

class CReportCtrl : public CWnd
{
	friend class CReportView;
	friend class CReportColumnListCtrl;

// Construction
public:
	CReportCtrl();
	DECLARE_DYNCREATE(CReportCtrl)

public:
	BOOL Create(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);

// Attributes
public:
	BOOL ModifyProperty(WPARAM wParam, LPARAM lParam);

	INT ActivateColumn(INT iColumn, INT iOrder = 0);
	BOOL DeactivateColumn(INT iColumn);
	BOOL IsActiveColumn(INT iColumn);

	BOOL GetItem(LPRVITEM lprvi);
	BOOL SetItem(LPRVITEM lprvi);
	
	INT GetItemText(INT iItem, INT iSubItem, LPTSTR lpszText, INT iLen);
	CString GetItemText(INT iItem, INT iSubItem);
	BOOL SetItemText(INT iItem, INT iSubItem, LPTSTR lpszText);

	INT GetItemImage(INT iItem, INT iSubItem);
	BOOL SetItemImage(INT iItem, INT iSubItem, INT iImage);

	INT GetItemCheck(INT iItem, INT iSubItem);
	BOOL SetItemCheck(INT iItem, INT iSubItem, INT iCheck = -1);

	DWORD GetItemData(INT iItem);
	BOOL SetItemData(INT iItem, DWORD dwData);

	INT GetVisibleCount(BOOL bUnobstructed = TRUE);
	INT GetItemCount();

	INT GetFirstSelectedItem();
	INT GetNextSelectedItem(INT iItem);

	BOOL SetImageList(CImageList* pImageList);
	CImageList* GetImageList();

	CFlatHeaderCtrl* GetHeaderCtrl();

	BOOL SetReportColumnListCtrl(CReportColumnListCtrl* lprclc);
	CReportColumnListCtrl* GetReportColumnListCtrl();

	BOOL SetSortCallback(LPFNRVCOMPARE lpfnrvc);
	LPFNRVCOMPARE GetSortCallback();

	BOOL WriteProfile(LPCTSTR lpszSection, LPCTSTR lpszEntry);
	BOOL GetProfile(LPCTSTR lpszSection, LPCTSTR lpszEntry);

// Operations
public:
	BOOL ModifyStyle(DWORD dwRemove, DWORD dwAdd, UINT nFlags = 0);

	INT DefineColumn(INT iColumn, LPRVCOLUMN lprvc, BOOL bUpdateList = FALSE);
	BOOL UndefineColumn(INT iColumn);

	INT InsertItem(INT iItem, LPTSTR lpszText, INT iImage = -1, INT iCheck = -1, INT iTextColor = -1);
	INT InsertItem(LPRVITEM lprvi);
	BOOL DeleteItem(INT iItem);
	BOOL DeleteAllItems();

	void RedrawItems(INT iFirst, INT iLast = -1);
	BOOL EnsureVisible(INT iItem, BOOL bUnobstructed = TRUE);

	INT InsertColor(INT iIndex, COLORREF crColor);
	BOOL DeleteColor(INT iIndex);

	INT HitTest(LPRVHITTESTINFO lprvhti);

	BOOL SortItems(INT iColumn, BOOL bAscending);

// Overrides
	virtual ~CReportCtrl();

	virtual void DrawItem(CDC* pDC, CRect rect, LPRVITEM lprvi);
	virtual INT CompareItems(INT iColumn, INT iItem1, INT iItem2);

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CReportCtrl)
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Structures
protected:

	typedef struct structSUBITEM
	{
		UINT nFormat;
		INT iWidth;
		INT iMinWidth;
		INT iMaxWidth;
		INT iImage;

		CString strText;

		structSUBITEM() : nFormat(RVCF_LEFT), iWidth(-1), iMinWidth(0), iMaxWidth(-1), iImage(0) {};

	} SUBITEM, FAR* LPSUBITEM;

	typedef struct structITEM
	{
		CReportData rdData;
		INT iBkColor;
		UINT nState;
		UINT nPreview;
		LPARAM lParam;

		structITEM() :
			iBkColor(-1),
			nPreview(0),
			nState(0),
			lParam(0)
			{};

		structITEM& operator = (structITEM& item)
		{
			rdData = item.rdData;

			iBkColor = item.iBkColor;
			nPreview = item.nPreview;
			nState = item.nState;
			lParam = item.lParam;

			return *this;
		}

	} ITEM, FAR* LPITEM;

// Implementation
protected:
	BOOL m_bSubclassFromCreate;

	BOOL m_bDoubleBuffer;
	INT m_iSpacing;

	CFont m_font;
	CFont m_fontBold;

	CImageList* m_pImageList;
	SIZE m_sizeImage;
	SIZE m_sizeCheck;

	COLORREF m_crBackground;
	COLORREF m_crBkSelected;
	COLORREF m_crBkSelectedNoFocus;
	COLORREF m_crText;
	COLORREF m_crTextSelected;
	COLORREF m_crTextSelectedNoFocus;
	COLORREF m_crGrid;

	CArray<COLORREF, COLORREF> m_arrayColors;
	CPalette m_palette;

	INT m_iGridStyle;

	CString m_strNoItems;

	CRect m_rectHeader;
	CRect m_rectReport;

	INT m_iDefaultWidth, m_iDefaultHeight;
	INT m_iVirtualWidth, m_iVirtualHeight;

	CArray<SUBITEM, SUBITEM> m_arraySubItems;
	CArray<ITEM, ITEM> m_arrayItems;

	BOOL m_bColumnsReordered;
	CArray<INT, INT> m_arrayColumns;

	BOOL m_bFocus;
	INT m_iFocusRow;
	INT m_iSelectRow;
	CArray<INT, INT> m_arrayRows;

	LPFNRVCOMPARE m_lpfnrvc;

	CFlatHeaderCtrl m_wndHeader;
	CReportColumnListCtrl* m_lprclc;

	BOOL Create();

	void GetSysColors();
	BOOL CreatePalette();

	BOOL Notify(UINT nCode, INT iItem = -1, INT iSubItem = -1, LPARAM lParam = 0);
	BOOL Notify(UINT nCode, UINT nKeys, LPRVHITTESTINFO lprvhti);

	void Layout(INT cx, INT cy);

	INT FindItem(INT iItem);
	INT FindColumnInHeader(INT iColumn);
	INT GetVisibleRows(BOOL bUnobstructed = TRUE, LPINT lpiFirst = NULL, LPINT lpiLast = NULL, BOOL bReverse = FALSE);
	void SelectRows(INT iFirst, INT iLast, BOOL bSelect = TRUE, BOOL bKeepSelection = FALSE, BOOL bInvert = FALSE);

    INT GetScrollPos32(INT iBar, BOOL bGetTrackPos = FALSE);
    BOOL SetScrollPos32(INT iBar, INT nPos, BOOL bRedraw = TRUE);
	void ScrollWindow(INT iBar, INT iPos);

	void DrawCtrl(CDC* pDC);
	INT DrawImage(CDC* pDC, CRect rect, LPRVITEM lprvi);
	INT DrawCheck(CDC* pDC, CRect rect, LPRVITEM lprvi);
	INT DrawText(CDC* pDC, CRect rect, LPRVITEM lprvi);

	// Generated message map functions
protected:
	//{{AFX_MSG(CReportCtrl)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	afx_msg void OnSysColorChange();
	afx_msg void OnHdnItemChanged(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnHdnItemClick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnHdnEndDrag(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg UINT OnGetDlgCode();
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg BOOL OnQueryNewPalette();
	afx_msg void OnPaletteChanged(CWnd* pFocusWnd);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	//}}AFX_MSG
    afx_msg LRESULT OnSetFont(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnGetFont(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CReportView

class CReportView : public CView
{
protected:
	CReportView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CReportView)

// Attributes
public:
	CReportCtrl& GetReportCtrl();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CReportView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CReportView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	BOOL m_bCreated;
	CReportCtrl m_wndReportCtrl;

	// Generated message map functions
protected:
	//{{AFX_MSG(CReportView)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CReportColumnList window

class CReportColumnListCtrl : public CDragListBox
{
// Construction
public:
	CReportColumnListCtrl();
	~CReportColumnListCtrl();

// Attributes
public:
	BOOL SetReportCtrl(CReportCtrl* pReportCtrl);
	CReportCtrl* GetReportCtrl();

// Operations
public:
	BOOL UpdateList();

// Overrides
	virtual BOOL Include(INT iColumn);

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CReportColumnListCtrl)
	public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
protected:
	CReportCtrl* m_pReportCtrl;

	INT m_iColumn;
	HDITEM m_hdiColumn;
	TCHAR m_szColumnText[FLATHEADER_TEXT_MAX];

	CFHDragWnd* m_pDragWnd;
	CRect m_rcDragWnd;
	CRect m_rcDropTarget1;
	CRect m_rcDropTarget2;

	INT m_iDropIndex;

	BOOL BeginDrag(CPoint pt);
	UINT Dragging(CPoint pt);
	void CancelDrag(CPoint pt);
	void Dropped(INT iSrcIndex, CPoint pt);

	// Generated message map functions
protected:
	//{{AFX_MSG(CReportColumnListCtrl)
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REPORTCTRL_H__279B1CA0_D7F2_11D2_88D7_ABB23645F26D__INCLUDED_)
