//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Protocol Manager.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_PROTOCOLMANAGER_DIALOG      102
#define IDS_PROC_RUN                    102
#define IDS_PROC_VIEW                   103
#define IDS_PROC_EDIT                   104
#define IDR_MAINFRAME                   128
#define IDD_OPTIONS                     129
#define IDB_BITMAP_LOGO                 134
#define IDB_BITMAP_ZYLUX                134
#define IDB_BITMAP_SOFTSTEP             138
#define IDB_BITMAP_BDS                  142
#define IDI_ICON_DATAFILE               144
#define IDI_ICON_PROTCOLFILE            145
#define IDR_MENU_COMMANDS               146
#define IDD_TMPDIALOG                   147
#define IDC_LIST_PROTOCOLS              1001
#define IDC_RUN                         1002
#define IDC_EDIT                        1003
#define IDC_GROUP_SERIAL                1003
#define IDC_DELETE                      1004
#define IDC_STATIC_PORT                 1004
#define IDC_RETRIEVE                    1005
#define IDC_STATIC_BAUD                 1005
#define IDC_OPTIONS                     1006
#define IDC_EDIT_PORT                   1006
#define IDC_GROUP_INJECTOR              1006
#define IDC_EDIT_BAUD                   1007
#define IDC_LIST_PROTOCOLTYPES          1007
#define IDC_STATIC_IPORT                1007
#define IDC_CREATE                      1008
#define IDC_STATIC_VOLUME               1008
#define IDC_GROUP_PROTOCOLS             1011
#define IDC_STATIC_WORKDIR              1011
#define IDC_EDIT_COMMENT                1012
#define IDC_EDIT_WORKDIR                1012
#define IDC_COMBO_PORT                  1013
#define IDC_EDIT_TYPECOMMENT            1013
#define IDC_COMBO_BAUD                  1014
#define IDC_BUTTON_WORKDIR              1015
#define IDC_EDIT1                       1016
#define IDC_COMBO_IPORT                 1016
#define IDC_COMBO_VOLUME                1017
#define IDC_STATIC_PROGICON             1018
#define IDC_STATIC_PROGSTR              1019
#define IDC_STATIC_USER                 1020
#define IDC_STATIC_SERSTR               1020
#define IDC_STATIC_VERSION              1020
#define IDC_STATIC_TYPES                1021
#define IDC_CHECK_BEEP                  1022
#define IDC_CHECK_INJECTOR              1023
#define IDC_VIEWFILE                    32771
#define IDC_PROTOCOLDONE                32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        149
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
