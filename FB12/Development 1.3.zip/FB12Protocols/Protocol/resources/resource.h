//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Protocol.rc
//
#define IDD_PPSDIALOG                   801
#define PPS_IDC_STATIC_PROTOCOLS        1000
#define PPS_IDC_LIST_PROTOCOLS          1001
#define PPS_IDC_STATIC_PROTOCOL         1002
#define PPS_IDC_EDIT_PROTOCOL           1003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        802
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
