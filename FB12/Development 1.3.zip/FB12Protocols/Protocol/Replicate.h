// Replicate.h: interface for the CReplicate class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_REPLICATE_H__8A30BBA1_34F0_11D1_AE1E_0080C80C9F0E__INCLUDED_)
#define AFX_REPLICATE_H__8A30BBA1_34F0_11D1_AE1E_0080C80C9F0E__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CReplicate  
{
public:
	bool m_used;
	long m_RLU;
	CReplicate();
	virtual ~CReplicate();

};

#endif // !defined(AFX_REPLICATE_H__8A30BBA1_34F0_11D1_AE1E_0080C80C9F0E__INCLUDED_)
