// Replicate.cpp: implementation of the CReplicate class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Replicate.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CReplicate::CReplicate() : m_RLU(0), m_used(false)
{

}

CReplicate::~CReplicate()
{

}
